export interface AuthTokenDto{
    token: string,
    timestamp: number
}