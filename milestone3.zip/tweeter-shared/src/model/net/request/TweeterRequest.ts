export interface TweeterRequest{
    readonly token: string
}